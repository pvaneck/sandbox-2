import argparse
import logging
import os
import pickle
import sys
import time

import numpy as np
import tensorflow as tf
from sklearn.svm import SVC
from tensorflow.python.platform import gfile

import embedding_loader
from embedding_loader import filter_dataset, split_dataset, get_dataset

logger = logging.getLogger(__name__)


# Path to model protobuf graph.
# model_path = './data/20180402-114759/20180402-114759.pb'
# # Input path of data to train on.
# input_dir = './processed-images'
# # Path to output the trained classifier model.
# classifier_output_path = './output-classifier.pkl'
# Size of batches to use during training.
batch_size = 128
# Number of threads to utlize for queue.-
num_threads = 16
# How many times to go through the entire train dataset.
num_epochs = 1
# Ratio to split train/test get_dataset
split_ratio = 0.7
# Minimum number of images per class.
min_images_per_class = 10
# Flag to determine if train or evaluate.
is_train = False


def main(model_path='./data/20180402-114759/20180402-114759.pb',
         input_dir = './processed-images',
         classifier_output_path = './output-classifier.pkl'):

    start_time = time.time()
    with tf.Session(config=tf.ConfigProto(log_device_placement=False)) as sess:
        train_set, test_set = _get_test_and_train_set(input_dir, min_num_images_per_label=min_images_per_class,
                                                      split_ratio=split_ratio)

        if is_train:
            dataset, class_names = _load_images_and_labels(train_set, True)
        else:
            dataset, class_names = _load_images_and_labels(test_set, False)

        _load_model(model_filepath=model_path)

        init_op = tf.group(tf.global_variables_initializer(), tf.local_variables_initializer())
        sess.run(init_op)

        images_placeholder = tf.get_default_graph().get_tensor_by_name("input:0")
        embedding_layer = tf.get_default_graph().get_tensor_by_name("embeddings:0")
        phase_train_placeholder = tf.get_default_graph().get_tensor_by_name("phase_train:0")

        emb_array, label_array = _create_embeddings(embedding_layer, dataset, images_placeholder,
                                                    phase_train_placeholder, sess)

        logger.info('Created {} embeddings'.format(len(emb_array)))

        classifier_filename = classifier_output_path

        if is_train:
            _train_and_save_classifier(emb_array, label_array, class_names, classifier_filename)
        else:
            _evaluate_classifier(emb_array, label_array, classifier_filename)

        logger.info('Completed in {} seconds'.format(time.time() - start_time))


def _get_test_and_train_set(input_dir, min_num_images_per_label, split_ratio=0.7):
    """
    Load train and test dataset. Classes with < :param min_num_images_per_label will be filtered out.
    :param input_dir:
    :param min_num_images_per_label:
    :param split_ratio:
    :return:
    """
    dataset = get_dataset(input_dir)
    dataset = filter_dataset(dataset, min_images_per_label=min_num_images_per_label)
    train_set, test_set = split_dataset(dataset, split_ratio=split_ratio)

    return train_set, test_set


def _load_images_and_labels(dataset, train=False):
    class_names = [cls.name for cls in dataset]
    image_paths, labels = embedding_loader.get_image_paths_and_labels(dataset)

    # If this is the training set.
    if train:
        data = tf.data.Dataset.from_tensor_slices((image_paths, labels)) \
            .shuffle(len(image_paths)) \
            .repeat(num_epochs) \
            .map(_preprocess_function, num_parallel_calls=num_threads) \
            .map(_train_augment_function, num_parallel_calls=num_threads) \
            .batch(batch_size) \
            .prefetch(1)
    # Otherwise, this is the testing set, so no repeating and
    # no image augmentation.
    else:
        data = tf.data.Dataset.from_tensor_slices((image_paths, labels)) \
            .shuffle(len(image_paths)) \
            .map(_preprocess_function, num_parallel_calls=num_threads) \
            .batch(batch_size) \
            .prefetch(1)

    return data, class_names


def _preprocess_function(image_path, label):
    image_size = 160
    file_contents = tf.read_file(image_path)
    image = tf.image.decode_jpeg(file_contents, channels=3)
    image = tf.random_crop(image, size=[image_size, image_size, 3])
    image.set_shape((image_size, image_size, 3))
    image = tf.image.per_image_standardization(image)
    return image, label


def _train_augment_function(image, label):
    image = tf.image.random_flip_left_right(image)
    image = tf.image.random_brightness(image, max_delta=0.3)
    image = tf.image.random_contrast(image, lower=0.2, upper=1.8)
    return image, label


def _load_model(model_filepath):
    """
    Load frozen protobuf graph
    :param model_filepath: Path to protobuf graph
    :type model_filepath: str
    """
    model_exp = os.path.expanduser(model_filepath)
    if os.path.isfile(model_exp):
        logging.info('Model filename: %s' % model_exp)
        with gfile.FastGFile(model_exp, 'rb') as f:
            graph_def = tf.GraphDef()
            graph_def.ParseFromString(f.read())
            tf.import_graph_def(graph_def, name='')
    else:
        logger.error('Missing model file. Exiting')
        sys.exit(-1)


def _create_embeddings(embedding_layer, dataset, images_placeholder, phase_train_placeholder, sess):
    """
    Uses model to generate embeddings from :param images.
    :param embedding_layer:
    :param dataset:
    :param images_placeholder:
    :param phase_train_placeholder:
    :param sess:
    :return: (tuple): image embeddings and labels
    """
    emb_array = None
    label_array = None
    try:
        i = 0
        iterator = dataset.make_one_shot_iterator()
        batch = iterator.get_next()
        while True:
            batch_images, batch_labels = sess.run(batch)
            logger.info('Processing iteration {} batch of size: {}'.format(i, len(batch_labels)))
            emb = sess.run(embedding_layer,
                           feed_dict={images_placeholder: batch_images, phase_train_placeholder: False})

            emb_array = np.concatenate([emb_array, emb]) if emb_array is not None else emb
            label_array = np.concatenate([label_array, batch_labels]) if label_array is not None else batch_labels
            i += 1

    except tf.errors.OutOfRangeError:
        pass

    return emb_array, label_array


def _train_and_save_classifier(emb_array, label_array, class_names, classifier_filename_exp):
    logger.info('Training Classifier')
    model = SVC(kernel='linear', probability=True, verbose=False)
    model.fit(emb_array, label_array)

    with open(classifier_filename_exp, 'wb') as outfile:
        pickle.dump((model, class_names), outfile)
    logging.info('Saved classifier model to file "%s"' % classifier_filename_exp)


def _evaluate_classifier(emb_array, label_array, classifier_filename):
    logger.info('Evaluating classifier on {} images'.format(len(emb_array)))
    if not os.path.exists(classifier_filename):
        raise ValueError('Pickled classifier not found, have you trained first?')

    with open(classifier_filename, 'rb') as f:
        model, class_names = pickle.load(f)

        predictions = model.predict_proba(emb_array, )
        best_class_indices = np.argmax(predictions, axis=1)
        best_class_probabilities = predictions[np.arange(len(best_class_indices)), best_class_indices]

        for i in range(len(best_class_indices)):
            print('%4d  %s: %.3f, Actual: %s' % (i, class_names[best_class_indices[i]], best_class_probabilities[i], class_names[label_array[i]]))

        accuracy = np.mean(np.equal(best_class_indices, label_array))
        print('Accuracy: %.3f' % accuracy)


def _classify_image(image_path, classifier_filename):
    if not os.path.exists(image_path):
        raise ValueError('Image path specified does not exist.')

    logger.info('Evaluating classifier on %s' % (image_path))
    if not os.path.exists(classifier_filename):
        raise ValueError('Pickled classifier not found, have you trained first?')

    with open(classifier_filename, 'rb') as f:
        model, class_names = pickle.load(f)



if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser(add_help=True)
    parser.add_argument('--model-path', type=str, action='store', dest='model_path',
                        help='Path to model protobuf graph')
    parser.add_argument('--input-dir', type=str, action='store', dest='input_dir',
                        help='Input path of data to train on')
    parser.add_argument('--classifier-path', type=str, action='store', dest='classifier_path',
                        help='Path to output trained classifier model')

    args = parser.parse_args(model_path=args)
    main(model_path=args.model_path,
         input_dir=args.input_dir,
         classifier_output_path=args.classifier_path)
    #_classify_image('./processed-images/Colin_Powell/Colin_Powell_0010.jpg', classifier_output_path)
